package dao;

import java.util.Collection;
import java.util.List;

import entity.Cases;
import entity.Incidents;
import entity.Reports;
import exception.IncidentNumberNotFoundException;

public interface ICrimeAnalysisService {
    boolean createIncident(Incidents incident);

    boolean updateIncidentStatus(int incidentId, String status) throws IncidentNumberNotFoundException;

    Collection<Incidents> getIncidentsInDateRange(String startDateStr, String endDateStr);

    Collection<Incidents> searchIncidents(Incidents criteria);

    Reports generateIncidentReport(Incidents incident);

    Cases createCase(String caseDescription, Collection<Incidents> incidents);

    Cases getCaseDetails(int caseId);

    Collection<Incidents> fetchIncidentsForCase(int caseId);

    boolean updateCaseDetails(Cases caseObj);

    List<Cases> getAllCases();

    Incidents getIncidentById(int incidentId);

    Object generateIncidentReport(Incidents incidentForReport, int reportingOfficerId);

    int getVictimIdByIncidentId(int incidentId);

    int getSuspectIdByIncidentId(int incidentId);
}

