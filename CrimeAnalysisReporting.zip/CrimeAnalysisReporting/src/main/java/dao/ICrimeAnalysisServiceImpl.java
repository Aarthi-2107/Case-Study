package dao;

import entity.Cases;
import entity.Incidents;
import entity.Reports;
import exception.IncidentNumberNotFoundException;
import util.DBConnection;
import util.PropertyUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class ICrimeAnalysisServiceImpl implements ICrimeAnalysisService {

    private Connection connection;
    public ICrimeAnalysisServiceImpl() {
        try {
            Properties properties = PropertyUtil.loadProperties("D:\\CrimeAnalysisReporting\\src\\main\\db.properties");
            String connectionString = PropertyUtil.getConnectionString(properties);
            this.connection = DBConnection.getConnection(connectionString);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception, log it, or throw a custom runtime exception if needed
            throw new RuntimeException("Failed to establish database connection", e);
        }
    }
    @Override
    public boolean createIncident(Incidents incident) {
        try {
            String sql = "INSERT INTO Incidents (IncidentID, IncidentType, IncidentDate, IncidentDescription, IncidentStatus, AgencyID, VictimID, SuspectID, Latitude, Longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, incident.getIncidentID());
                preparedStatement.setString(2, incident.getIncidentType());
                if (incident.getIncidentDate() != null) {
                    preparedStatement.setDate(3, new java.sql.Date(incident.getIncidentDate().getTime()));
                } else {
                    System.out.println("Incident Date is null.");
                    return false;
                }
                preparedStatement.setString(4, incident.getIncidentDescription());
                preparedStatement.setString(5, incident.getIncidentStatus());
                preparedStatement.setInt(6, incident.getAgencyID());
                preparedStatement.setInt(7, incident.getVictimID());
                preparedStatement.setInt(8, incident.getSuspectID());
                preparedStatement.setDouble(9, incident.getLatitude());
                preparedStatement.setDouble(10, incident.getLongitude());
                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



    @Override
    public boolean updateIncidentStatus(int incidentId, String status) throws IncidentNumberNotFoundException {
        try {
            String sql = "UPDATE Incidents SET IncidentStatus = ? WHERE IncidentID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, status);
                preparedStatement.setInt(2, incidentId);

                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Incident status updated successfully.");
                    return true;
                } else {
                    throw new IncidentNumberNotFoundException("Incident number not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public Collection<Incidents> searchIncidents(Incidents criteria) {
        List<Incidents> incidents = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Incidents WHERE IncidentType LIKE ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, "%" + criteria.getIncidentType() + "%");

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Incidents incident = new Incidents();
                        incident.setIncidentID(resultSet.getInt("incidentID"));
                        incident.setIncidentType(resultSet.getString("incidentType"));
                        incident.setIncidentDate(resultSet.getDate("incidentDate"));
                        incident.setIncidentDescription(resultSet.getString("IncidentDescription"));
                        incident.setIncidentStatus(resultSet.getString("IncidentStatus"));
                        incidents.add(incident);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incidents;
    }



    @Override
    public Incidents getIncidentById(int incidentId) {
        Incidents incident = null;
        try {
            String sql = "SELECT * FROM Incidents WHERE IncidentID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, incidentId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        incident = new Incidents();
                        incident.setIncidentID(resultSet.getInt("IncidentID"));
                        incident.setIncidentType(resultSet.getString("IncidentType"));
                        incident.setIncidentDate(resultSet.getDate("IncidentDate"));
                        incident.setLatitude(resultSet.getDouble("Latitude"));
                        incident.setLongitude(resultSet.getDouble("Longitude"));
                        incident.setIncidentDescription(resultSet.getString("IncidentDescription"));
                        incident.setIncidentStatus(resultSet.getString("IncidentStatus"));
                        incident.setAgencyID(resultSet.getInt("AgencyID"));
                        incident.setAgencyID(resultSet.getInt("victimID"));
                        return incident;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Incidents> getIncidentsInDateRange(String startDateStr, String endDateStr) {
        List<Incidents> incidentsList = new ArrayList<>();
        try {

            String sql = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date startDate = new java.sql.Date(dateFormat.parse(startDateStr).getTime());
                Date endDate = new java.sql.Date(dateFormat.parse(endDateStr).getTime());
                preparedStatement.setDate(1, startDate);
                preparedStatement.setDate(2, endDate);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Incidents incident = new Incidents();
                        incident.setIncidentID(resultSet.getInt("incidentID"));
                        incident.setIncidentType(resultSet.getString("incidentType"));
                        incident.setIncidentDate(resultSet.getDate("incidentDate"));
                        incident.setIncidentDescription(resultSet.getString("incidentdescription"));
                        incident.setIncidentStatus(resultSet.getString("incidentstatus"));
                        incident.setVictimID(resultSet.getInt("victimID"));
                        incident.setSuspectID(resultSet.getInt("suspectID"));
                        incidentsList.add(incident);
                    }
                }
            }
        } catch (SQLException | ParseException e) {
            e.printStackTrace();
        }
        return incidentsList;
    }

    @Override
    public Object generateIncidentReport(Incidents incidentForReport, int reportingOfficerId) {
        try {
            String reportDetails = "Incident Report\n"
                    + "Incident Type: " + incidentForReport.getIncidentType() + "\n"
                    + "Incident Date: " + incidentForReport.getIncidentDate() + "\n"
                    + "Location: " + incidentForReport.getLatitude() + ", " + incidentForReport.getLongitude() + "\n"
                    + "Description: " + incidentForReport.getIncidentDescription() + "\n"
                    + "Status: " + incidentForReport.getIncidentStatus();

            Map<String, Object> reportObject = new HashMap<>();
            reportObject.put("reportDetails", reportDetails);
            reportObject.put("reportDate", new java.util.Date());
            reportObject.put("status", "Draft");

            // Assuming you have a Reports table in the database to store incident reports
            String insertReportQuery = "INSERT INTO Reports (ReportID, IncidentID, ReportingOfficer, ReportDate, ReportDetails, ReportStatus) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";



            try (PreparedStatement statement = connection.prepareStatement(insertReportQuery, Statement.RETURN_GENERATED_KEYS)) {
                int reportID = generateUniqueReportID();
                statement.setInt(1, reportID); // Set report ID
                statement.setInt(2, incidentForReport.getIncidentID()); // Set incident ID
                statement.setInt(3, reportingOfficerId); // Set reporting officer ID
                statement.setDate(4, new java.sql.Date(new java.util.Date().getTime())); // Set report date
                statement.setString(5, reportDetails); // Set report details
                statement.setString(6, "Draft"); // Set report status


                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    ResultSet generatedKeys = statement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int generatedReportID = generatedKeys.getInt(1);
                        reportObject.put("reportID", generatedReportID);
                    }

                    System.out.println("Incident report saved to the database.");
                } else {
                    System.out.println("Failed to save incident report to the database.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }

            return reportObject;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    private int generateUniqueReportID() {
        try {
            String sql = "SELECT MAX(ReportID) FROM Reports";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt(1) + 1; // Increment the maximum report ID by 1
                    } else {
                        return 1; // If there are no existing reports, start with ID 1
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Return a negative value to indicate failure
        }
    }

    @Override
    public Cases createCase(String caseDescription, Collection<Incidents> incidents) {
        try {
            // Insert the case into the database
            String insertCaseQuery = "INSERT INTO Cases (caseDescription) VALUES (?)";
            try (PreparedStatement statement = connection.prepareStatement(insertCaseQuery, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, caseDescription);
                int rowsAffected = statement.executeUpdate();

                if (rowsAffected == 0) {
                    throw new SQLException("Creating case failed, no rows affected.");
                }

                // Retrieve the auto-generated case ID
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int caseId = generatedKeys.getInt(1);

                        // Update the incidentIds column in the Cases table with the associated incident IDs
                        String updateIncidentIdsQuery = "UPDATE Cases SET incidentIds = ? WHERE caseId = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateIncidentIdsQuery)) {
                            StringBuilder incidentIdsBuilder = new StringBuilder();
                            for (Incidents incident : incidents) {
                                incidentIdsBuilder.append(incident.getIncidentID()).append(",");
                            }
                            // Remove the last comma
                            incidentIdsBuilder.deleteCharAt(incidentIdsBuilder.length() - 1);
                            String incidentIds = incidentIdsBuilder.toString();

                            updateStatement.setString(1, incidentIds);
                            updateStatement.setInt(2, caseId);
                            updateStatement.executeUpdate();
                        }

                        // Create and return the Cases object with the associated incident IDs
                        Cases newCase = new Cases();
                        newCase.setCaseId(caseId);
                        newCase.setCaseDescription(caseDescription);
                        newCase.setAssociatedIncidents(incidents);
                        return newCase;
                    } else {
                        throw new SQLException("Creating case failed, no ID obtained.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }



    @Override
    public Cases getCaseDetails(int caseId) {
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Cases caseDetails = null;

        try {
            String query = "SELECT * FROM cases WHERE caseId = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, caseId);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String caseDescription = resultSet.getString("caseDescription");
                Collection<Incidents> associatedIncidents = fetchIncidentsForCase(caseId);
                caseDetails = new Cases(caseId, caseDescription, associatedIncidents);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(statement, resultSet);
        }

        return caseDetails;
    }

    @Override
    public Collection<Incidents> fetchIncidentsForCase(int caseId) {
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Collection<Incidents> associatedIncidents = new ArrayList<>();

        try {
            String query = "SELECT incidentIds FROM cases WHERE caseId = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, caseId);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String incidentIds = resultSet.getString("incidentIds");
                if (incidentIds != null && !incidentIds.isEmpty()) {
                    String[] incidentIdArray = incidentIds.split(",");
                    for (String incidentIdStr : incidentIdArray) {
                        int incidentId = Integer.parseInt(incidentIdStr);
                        // Fetch incident details using existing method
                        Incidents incident = getIncidentById(incidentId);
                        if (incident != null) {
                            associatedIncidents.add(incident);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(statement, resultSet);
        }

        return associatedIncidents;
    }

    private void closeResources(PreparedStatement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean updateCaseDetails(Cases caseObj) {
        PreparedStatement statement = null;
        try {
            String updateQuery = "UPDATE cases SET caseDescription = ? WHERE caseId = ?";
            statement = connection.prepareStatement(updateQuery);
            statement.setString(1, caseObj.getCaseDescription());
            statement.setInt(2, caseObj.getCaseId());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(statement, null);
        }
    }

    @Override
    public List<Cases> getAllCases() {
        List<Cases> casesList = new ArrayList<>();
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            String query = "SELECT * FROM cases";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int caseId = resultSet.getInt("caseId");
                String caseDescription = resultSet.getString("caseDescription");
                Collection<Incidents> associatedIncidents = fetchIncidentsForCase(caseId);
                Cases caseDetails = new Cases(caseId, caseDescription, associatedIncidents);
                casesList.add(caseDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(statement, resultSet);
        }

        return casesList;
    }


    @Override
    public int getVictimIdByIncidentId(int incidentId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getVictimIdByIncidentId'");
    }
    @Override
    public int getSuspectIdByIncidentId(int incidentId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getSuspectIdByIncidentId'");
    }

    @Override
    public Reports generateIncidentReport(Incidents incident) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'generateIncidentReport'");
    }
}
