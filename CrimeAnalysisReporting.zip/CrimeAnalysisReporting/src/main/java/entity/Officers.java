package entity;

public class Officers {
    private int officerID;
    private String firstName;
    private String lastName;
    private String badgeNumber;
    private String officerRank;
    private String contactInformation;
    private int agencyID;

    public Officers() {
    }

    public Officers(int officerID, String firstName, String lastName, String badgeNumber, String rank, String contactInformation, int agencyID) {
        this.officerID = officerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.badgeNumber = badgeNumber;
        this.officerRank = rank;
        this.contactInformation = contactInformation;
        this.agencyID = agencyID;
    }

    public int getOfficerID() {
        return officerID;
    }

    public void setOfficerID(int officerID) {
        this.officerID = officerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBadgeNumber() {
        return badgeNumber;
    }

    public void setBadgeNumber(String badgeNumber) {
        this.badgeNumber = badgeNumber;
    }

    public String getRank() {
        return officerRank;
    }

    public void setRank(String rank) {
        this.officerRank = rank;
    }

    public String getContactInformation() {
        return contactInformation;
    }

    public void setContactInformation(String contactInformation) {
        this.contactInformation = contactInformation;
    }

    public int getAgencyID() {
        return agencyID;
    }

    public void setAgencyID(int agencyID) {
        this.agencyID = agencyID;
    }

    @Override
    public String toString() {
        return "Officer{" +
                "officerID=" + officerID +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", badgeNumber='" + badgeNumber + '\'' +
                ", rank='" + officerRank + '\'' +
                ", contactInformation='" + contactInformation + '\'' +
                ", agencyID=" + agencyID +
                '}';
    }
}

