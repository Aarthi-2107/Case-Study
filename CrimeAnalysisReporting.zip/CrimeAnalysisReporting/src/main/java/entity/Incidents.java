package entity;

import java.sql.Date;

public class Incidents {
    private int incidentID;
    private String incidentType;
    private Date incidentDate;
    private double latitude;
    private double longitude;
    private String incidentDescription;
    private String incidentStatus;
    private int agencyID;
    private int victimID;
    private int suspectID;

    // Constructors
    public Incidents(int incidentID, String incidentType, Date incidentDate, double latitude, double longitude,
                     String incidentDescription, String incidentStatus, int victimID, int suspectID, int reportingOfficerId, int agencyID) {
        this.incidentID = incidentID;
        this.incidentType = incidentType;
        this.incidentDate = incidentDate;
        this.latitude = latitude;
        this.longitude = longitude;
        this.incidentDescription = incidentDescription;
        this.incidentStatus = incidentStatus;
        this.victimID = victimID;
        this.suspectID = suspectID;
        this.agencyID = agencyID;
    }

    public Incidents() {
    }

    // Getters and setters
    public int getIncidentID() {
        return incidentID;
    }

    public void setIncidentID(int incidentID) {
        this.incidentID = incidentID;
    }

    public String getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(String incidentType) {
        this.incidentType = incidentType;
    }

    public Date getIncidentDate() {
        return incidentDate;
    }

    public void setIncidentDate(Date incidentDate) {
        this.incidentDate = incidentDate;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getIncidentDescription() {
        return incidentDescription;
    }

    public void setIncidentDescription(String incidentDescription) {
        this.incidentDescription = incidentDescription;
    }

    public String getIncidentStatus() {
        return incidentStatus;
    }

    public void setIncidentStatus(String incidentStatus) {
        this.incidentStatus = incidentStatus;
    }


    public int getAgencyID() {
        return agencyID;
    }

    public void setAgencyID(int agencyID) {
        this.agencyID = agencyID;
    }

    public int getVictimID() {
        return victimID;
    }

    public void setVictimID(int victimID) {
        this.victimID = victimID;
    }

    public int getSuspectID() {
        return suspectID;
    }

    public void setSuspectID(int suspectID) {
        this.suspectID = suspectID;
    }

    public Object getReportDate() {
        throw new UnsupportedOperationException("Unimplemented method 'getReportDate'");
    }
}

