package entity;

import java.util.Collection;

public class Cases {
    private int caseId;
    private String caseDescription;
    private Collection<Incidents> associatedIncidents;

    public Cases(int caseId, String caseDescription, Collection<Incidents> associatedIncidents) {
        this.caseId = caseId;
        this.caseDescription = caseDescription;
        this.associatedIncidents = associatedIncidents;
    }


    public Cases() {
    }

    public String getCaseDescription() {
        return caseDescription;
    }

    public void setCaseDescription(String caseDescription) {
        this.caseDescription = caseDescription;
    }

    public Collection<Incidents> getAssociatedIncidents() {
        return associatedIncidents;
    }

    public void setAssociatedIncidents(Collection<Incidents> associatedIncidents) {
        this.associatedIncidents = associatedIncidents;
    }

    public int getCaseId() {
        return caseId;
    }

    public void setCaseId(int caseId) {
        this.caseId = caseId;
    }

}


